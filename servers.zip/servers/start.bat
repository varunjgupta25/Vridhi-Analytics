@echo off
title Vridhi Analytics - Multi-Bank Dedicated Server Launcher
color 0A

:: This delegates to the main project launcher in the parent directory
cd /d "%~dp0\.."
call start_all_bank_servers.bat
